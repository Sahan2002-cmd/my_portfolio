'use client';

import { useSelector } from 'react-redux';
import { Briefcase } from 'lucide-react';

// Hardcoded fallback in case database is empty
const defaultWorkExperience = [
  {
    role: 'Training Bank Associate',
    company: 'Peoples Bank Battaramulla',
    period: 'September 2022 - September 2023',
    description: 'Managed cash deposits, withdrawals, passbook services, cheque processing, account operations, and debit card issuance. Developed strong attention to detail and customer service skills in a professional banking environment.',
  },
];

export default function About() {
  const { experience } = useSelector((state: any) => state.portfolio);
  
  // Filter for work experience and sort
  const workExperience = experience && experience.length > 0
    ? [...experience].filter((exp: any) => exp.type === 'work').sort((a: any, b: any) => a.order - b.order)
    : defaultWorkExperience;

  return (
    <section
      id="about"
      className="min-h-screen flex items-center justify-center py-20 px-6 sm:px-12 relative"
    >
      <div className="glass-card max-w-4xl w-full p-8 md:p-12 relative z-10">
        <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight mb-8">
          <span className="bg-gradient-to-r from-[#00f5ff] to-[#14b8a6] bg-clip-text text-transparent">
            About Me
          </span>
        </h2>

        <div className="space-y-6 text-gray-300 leading-relaxed text-base md:text-lg">
          <p>
            I&apos;m a motivated 3rd-year Information Technology undergraduate at SLIIT with practical experience in full-stack web development and a growing interest in AI/ML technologies. My journey in software development has equipped me with strong foundations in building robust applications using modern technologies.
          </p>
          <p>
            I specialize in the MERN stack and have hands-on experience with Java, Python, and various database systems including MySQL, MongoDB, and SQL Server. Through academic and personal projects, I&apos;ve developed solutions for e-commerce platforms, transport systems, insurance management, and more.
          </p>
          <p>
            As a self-motivated team player with strong problem-solving and leadership skills, I&apos;m seeking Software Engineering opportunities to apply my technical knowledge and continuously enhance my professional capabilities.
          </p>
        </div>

        {/* Work Experience Sub-section */}
        <div className="mt-12 pt-8 border-t border-white/5">
          <div className="flex items-center gap-3 mb-8">
            <div className="p-2 bg-[#00f5ff]/10 rounded-lg border border-[#00f5ff]/25 text-[#00f5ff]">
              <Briefcase className="w-6 h-6" />
            </div>
            <h3 className="text-2xl font-bold text-white">Work Experience</h3>
          </div>

          <div className="space-y-6">
            {workExperience.map((exp: any, index: number) => (
              <div
                key={exp._id || index}
                className="p-6 bg-white/3 hover:bg-white/5 border border-white/5 hover:border-[#00f5ff]/20 rounded-xl transition-all duration-300 group"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                  <h4 className="text-lg md:text-xl font-bold text-white group-hover:text-[#00f5ff] transition-colors">
                    {exp.role}
                  </h4>
                  <span className="text-xs md:text-sm font-semibold text-[#00f5ff] bg-[#00f5ff]/10 px-3 py-1 rounded-full border border-[#00f5ff]/20 w-fit">
                    {exp.period}
                  </span>
                </div>
                <h5 className="text-sm md:text-base font-medium text-gray-400 mb-4">
                  {exp.company}
                </h5>
                {exp.description && (
                  <p className="text-gray-300 text-sm md:text-base leading-relaxed">
                    {exp.description}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
