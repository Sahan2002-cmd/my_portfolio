'use client';

import { useEffect, useRef } from 'react';
import * as THREE from 'three';

export default function ThreeBackground() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x030014, 0.002);

    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    camera.position.z = 50;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    containerRef.current.appendChild(renderer.domElement);

    // Particles
    const isMobile = window.innerWidth < 768;
    const particleCount = isMobile ? 800 : 2000;
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i += 3) {
      positions[i] = (Math.random() - 0.5) * 200;
      positions[i + 1] = (Math.random() - 0.5) * 200;
      positions[i + 2] = (Math.random() - 0.5) * 200;

      const color = new THREE.Color();
      color.setHSL(Math.random() * 0.3 + 0.5, 1, 0.5);
      colors[i] = color.r;
      colors[i + 1] = color.g;
      colors[i + 2] = color.b;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const material = new THREE.PointsMaterial({
      size: isMobile ? 1.5 : 2,
      vertexColors: true,
      transparent: true,
      opacity: 0.8,
      blending: THREE.AdditiveBlending,
      sizeAttenuation: true,
    });

    const particles = new THREE.Points(geometry, material);
    scene.add(particles);

    // Floating wireframe shapes
    const shapes: THREE.Mesh[] = [];
    if (!isMobile) {
      const geometries = [
        new THREE.TorusGeometry(5, 2, 16, 100),
        new THREE.OctahedronGeometry(5),
        new THREE.IcosahedronGeometry(5),
        new THREE.TetrahedronGeometry(5),
      ];
      const positionsArr = [
        { x: -40, y: 30, z: -30 },
        { x: 40, y: -30, z: -20 },
        { x: -30, y: -40, z: -25 },
        { x: 35, y: 35, z: -35 },
      ];
      geometries.forEach((geom, i) => {
        const mat = new THREE.MeshPhongMaterial({
          color: i % 2 === 0 ? 0x00f5ff : 0x7c3aed,
          wireframe: true,
          transparent: true,
          opacity: 0.2,
          side: THREE.DoubleSide,
        });
        const mesh = new THREE.Mesh(geom, mat);
        mesh.position.set(positionsArr[i].x, positionsArr[i].y, positionsArr[i].z);
        scene.add(mesh);
        shapes.push(mesh);
      });
    }

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.15);
    scene.add(ambientLight);
    const light1 = new THREE.PointLight(0x00f5ff, 2, 100);
    light1.position.set(50, 50, 50);
    scene.add(light1);
    const light2 = new THREE.PointLight(0x7c3aed, 2, 100);
    light2.position.set(-50, -50, 50);
    scene.add(light2);

    const mouse = { x: 0, y: 0 };
    const target = { x: 0, y: 0 };

    const onMouseMove = (e: MouseEvent) => {
      mouse.x = (e.clientX / window.innerWidth) * 2 - 1;
      mouse.y = -(e.clientY / window.innerHeight) * 2 + 1;
    };

    const onResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };

    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('resize', onResize);

    let animId: number;
    const animate = () => {
      animId = requestAnimationFrame(animate);

      particles.rotation.y += 0.0008;
      particles.rotation.x += 0.0004;

      const time = Date.now() * 0.001;
      shapes.forEach((shape, i) => {
        shape.rotation.x += 0.005 * (i + 1);
        shape.rotation.y += 0.005 * (i + 1);
        shape.position.y += Math.sin(time * 0.5 + i) * 0.015;
      });

      target.x += (mouse.x - target.x) * 0.05;
      target.y += (mouse.y - target.y) * 0.05;

      camera.position.x = target.x * 15;
      camera.position.y = target.y * 15;
      camera.lookAt(scene.position);

      const scrolled = window.scrollY;
      particles.rotation.z = scrolled * 0.00015;

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('resize', onResize);
      renderer.dispose();
      if (containerRef.current && renderer.domElement.parentNode === containerRef.current) {
        containerRef.current.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-0"
      style={{ pointerEvents: 'none' }}
    />
  );
}
