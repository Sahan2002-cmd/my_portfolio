import { NextResponse } from 'next/server';
import dbConnect from '@/lib/dbConnect';
import Experience from '@/lib/models/Experience';
import { verifyAdminRequest } from '@/lib/jwt';

export async function GET() {
  try {
    await dbConnect();
    const experiences = await Experience.find({}).sort({ order: 1 });
    return NextResponse.json(experiences);
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || 'Failed to fetch experience' },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    const admin = await verifyAdminRequest();
    if (!admin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    await dbConnect();
    const data = await req.json();

    if (!data.role || !data.company || !data.period || !data.type) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const experience = await Experience.create(data);
    return NextResponse.json(experience, { status: 201 });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || 'Failed to create experience' },
      { status: 500 }
    );
  }
}
