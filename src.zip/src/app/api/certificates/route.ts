import { NextResponse } from 'next/server';
import dbConnect from '@/lib/dbConnect';
import Certificate from '@/lib/models/Certificate';
import { verifyAdminRequest } from '@/lib/jwt';

export async function GET() {
  try {
    await dbConnect();
    const certificates = await Certificate.find({}).sort({ year: -1 });
    return NextResponse.json(certificates);
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || 'Failed to fetch certificates' },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    const admin = await verifyAdminRequest();
    if (!admin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    await dbConnect();
    const data = await req.json();

    if (!data.title || !data.organization || !data.year) {
      return NextResponse.json(
        { error: 'Missing required fields (title, organization, and year are required)' },
        { status: 400 }
      );
    }

    const certificate = await Certificate.create(data);
    return NextResponse.json(certificate, { status: 201 });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || 'Failed to create certificate' },
      { status: 500 }
    );
  }
}
